<?php
session_start();

include_once './database.php';

$msg = '';
$search = $_GET['search'] ?? '';
$sortFrom = $_GET['sortFrom'] ?? '';
$sortTo = $_GET['sortTo'] ?? date('Y-m-d H');
$a0 = '00:00:00';
$b0 = '23:59:59';

$RecordsPerPage = 10;
$page = '1';

// GETS id and name of country from previous selected page
//////////////////////////////////////////////////////////
if(isset($_POST['submitCountry'])){
    $_SESSION['countryId'] = $_GET['id'];
    $_SESSION['countryName'] = $_GET['name'];
}

// GET selected page of table
/////////////////////////////
if(isset($_GET['page'])){
    $page = $_GET['page'];
    } else{
        $page = 1;
}

$startFrom = ($page - 1) * $RecordsPerPage;


// SET ASC or DESC value from input
//////////////////////////
$sort = $_SESSION['sort'];
if(isset($_GET['sort'])){
    if($sort == 'ASC'){
        $sort = 'DESC';
        $_SESSION['sort'] = $sort;
    } else {
        $sort = 'ASC';
        $_SESSION['sort'] = $sort;
    }
}

// Check inputs of picked date
/////////////////////////////
if(empty($sortFrom)){
    $sortFrom = '2021-01-01';
    $sqlBetween = '';
} else {
    if(empty($sortTo)){
        $sortTo = date('Y-m-d');
    }
    $sqlBetween = 'AND date BETWEEN "' . $sortFrom . ' ' . $a0 . '" AND "' . $sortTo . ' ' . $b0 . '" ';
}

// Check or seacrh input was entered
/////////////////////////////////////
if ($search) {
    $statement = $pdo->prepare('SELECT * FROM cities WHERE name LIKE :name AND fk_country = :id ' . $sqlBetween . ' ORDER BY name ' . $sort . ' LIMIT ' . $startFrom . ", " . $RecordsPerPage);
    $statement->bindValue(':name', "%$search%");
    $statement->bindValue(':id', $_SESSION['countryId']);
    } else {
        $statement = $pdo->prepare('SELECT * FROM cities WHERE fk_country = :id ' . $sqlBetween . ' ORDER BY name ' . $sort . ' LIMIT ' . $startFrom . ", " . $RecordsPerPage);
        $statement->bindValue(':id', $_SESSION['countryId']);
}
$statement->execute();
$cities = $statement->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css">

    <title>Cities</title>
</head>
<body>
<h1>Cities of <?php echo $_SESSION['countryName']?></h1>
<div style="display: flex; margin-bottom: 15px">
    <form style="margin-right: 5%;" action="" method="GET">
            <input type="submit" name="sort" value="<?php echo $sort ?>">
        </form>
    <form>
        <input type="date" placeholder=" From" name="sortFrom" value="<?php echo $sortFrom ?>">
        <input type="date" placeholder=" To" name="sortTo" value="<?php echo $sortTo ?>">
        <input type="text" placeholder=" Search" name="search" value="<?php echo $search ?>">
        <button href="#?id=<?php $_SESSION['countryId'] ?>" type="submit" method="GET">Search</button>
    </form>
    </div>
<div class="allCountries">
    <table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>City Area, km²</th>
            <th>Population</th>
            <th>City postal Code</th>
            <th>Record Create Date</th>
            <th>Operations</th>
        </tr>
    </thead>
    <?php foreach($cities as $i => $city): ?>
            <tbody>
                <tr>
                <td><?php echo $i +1 ?></td>
                <td><?php echo $city['name'] ?></td>
                <td><?php echo $city['area'] ?></td>
                <td><?php echo $city['population'] ?></td>
                <td><?php echo $city['code'] ?></td>
                <td><?php echo $city['date'] ?></td>
                <td>
                    <div style="display: flex">
                        <a class="edit" href="update.php?id=<?php echo $city['id']?>&name=<?php echo $city['name']?>">Edit</a>
                        <form action="delete.php" method="POST">
                            <input type="hidden" name="idCity" value="<?php echo $city['id'] ?>">
                            <input type="submit" value="Delete"></input>
                        </form>
                    </div>
                </td>
                </tr>
            </tbody>
                <?php endforeach; ?>
    </table>
        <!-- Gets number of rows from database and sets number of table pages-->
        <!-- ----------------------------------------------- -->
    <div>
        <?php
            $statement = $pdo->prepare('SELECT count(*) list FROM cities WHERE name LIKE :name AND fk_country = :id');
            $statement->bindValue(':name', "%$search%");
            $statement->bindValue(':id', $_SESSION['countryId']);
            $statement->execute();
            $list = $statement->fetch(PDO::FETCH_COLUMN);
            $totalPages = ceil($list/$RecordsPerPage);
            for($i=1; $i<=$totalPages; $i++){
                echo "<a style='margin:3px' href='cities.php?page=" . $i . "'>" . $i . "</a>";
            }

        ?>
    </div>
    <p><?php echo $msg; ?></p>
</div>
            <!-- button to show and hide create new city form -->
            <!-- ----------------------------------------------- -->
            <button id="btnAddCountry" class="btnAdd" type="button" onclick="showHideAdd()">Add City</button>

                <!-- Form to create new country -->
                <!-- ----------------------------------------------- -->
                <div id="addCity" class="addRecord" style="visibility: hidden">
        <form  class="addRecord" action="create.php" method="POST">
            <h1>Add City</h1>
            <label>City name</label>
            <input type="text" placeholder="City name" name="name">
            <label>City area, km²</label>
            <input type="number" placeholder="City area, km²" name="area">
            <label>Population</label>
            <input type="number" placeholder="Population" name="population">
            <label>City postal code</label>
            <input type="text" placeholder="City postal code" name="postalCode">
            <input type="submit" class="inputSubmit" value="Submit" name="submitCity"></input>
        </form>
    </div>

<script>
    var addDiv = document.getElementById('addCity');
    function showHideAdd(){
        console.log(addDiv.style.visibility);
            if(addDiv.style.visibility == 'hidden'){
                addDiv.style.visibility = 'visible';
            } 
            else if (addDiv.style.visibility == 'visible'){
                addDiv.style.visibility = 'hidden';
            }
        }
        var updateDiv = document.getElementById('updateCountry');
        function showHideUpdate(){
            console.log(updateDiv.style.visibility);
        if(updateDiv.style.visibility == 'hidden'){
            updateDiv.style.visibility = 'visible';
        } 
        else if (updateDiv.style.visibility == 'visible'){
            updateDiv.style.visibility = 'hidden';
        }
    }
</script>
</body>
</html>