<?php
session_start();

require_once './database.php';

echo "delete.php";
$id = $_POST['id'] ?? null;
$cityId = $_POST['idCity'] ?? null;

echo "cityID = " . $cityId . '<br>';
echo "ID_POST = " . $id . '<br>';
echo "countryID = " .  $_SESSION['countryId'];
echo "countryName = " .  $_SESSION['countryName'];

// Delete City
///////////////
if(isset($_POST['idCity'])){
            $statement = $pdo->prepare('DELETE FROM cities WHERE id = :id');
            $statement->bindValue(':id', $cityId);
            $statement->execute();

        header("Location: cities.php");
}

// Delete Country
//////////////////
if(isset($_POST['id'])){
            $statement = $pdo->prepare('DELETE FROM countries WHERE id = :id');
            $statement->bindValue(':id', $id);
            $statement->execute();

        header("Location: index.php");
}