-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2021 at 03:14 PM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pasaulis`
--

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `fk_country` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `area` float(15,3) NOT NULL,
  `population` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `fk_country`, `name`, `area`, `population`, `code`, `date`) VALUES
(28, 37, 'KAUNAS', 0.000, 0, '', '2021-01-10 16:29:09'),
(29, 37, 'Vilnius', 5555.000, 13121, 'dsad', '2021-01-08 11:34:26'),
(31, 38, 'Ventspils', 565.000, 24, 'dsad', '2021-01-07 22:37:01'),
(34, 39, 'Parnu', 646.000, 56356, '53563', '2021-01-09 22:37:56'),
(36, 39, 'TALINAS', 0.000, 0, '', '2021-01-10 15:31:04'),
(50, 45, 'Maskva', 0.000, 0, '', '2021-01-10 14:39:32'),
(55, 37, 'Klaipeda', 0.000, 0, '', '2021-01-06 15:34:49'),
(60, 59, 'nezinomas', 98897880.000, 879879, '879', '2021-01-05 16:53:06'),
(81, 38, 'Ryga', 0.000, 0, '', '2021-01-08 12:00:25'),
(82, 38, 'Daugpilis', 0.000, 0, '', '2021-01-11 12:00:48'),
(83, 38, 'Liepoja', 0.000, 0, '', '2021-01-07 12:00:58'),
(84, 38, 'Ryga', 0.000, 0, '', '2021-01-11 12:01:04'),
(85, 38, 'Liepoja', 0.000, 0, '', '2021-01-11 12:01:07'),
(86, 38, 'Ryga', 0.000, 0, '', '2021-01-06 12:01:10'),
(87, 38, 'Ventspils', 0.000, 0, '', '2021-01-07 12:01:12'),
(88, 38, 'Daugpilis', 0.000, 0, '', '2021-01-09 12:01:18'),
(89, 38, 'Ventspils', 0.000, 0, '', '2021-01-02 12:01:24'),
(90, 38, 'Jelgava', 0.000, 0, '', '2021-01-11 12:01:34'),
(91, 38, 'Jelgava', 0.000, 0, '', '2021-01-10 12:01:42'),
(92, 38, 'Liepoja', 0.000, 0, '', '2021-01-05 12:01:48');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `area` bigint(20) NOT NULL,
  `population` bigint(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `area`, `population`, `code`, `date`) VALUES
(37, 'Lietuva', 777, 777, '777', '2021-01-07 13:34:43'),
(38, 'aLatvija  - daugiausiai miestu', 0, 0, '', '2021-01-11 13:53:05'),
(39, 'Estija', 3543, 3543, '3543', '2021-01-09 20:45:35'),
(45, 'Rusija', 99999, 143, '3213', '2021-01-10 11:23:10'),
(59, 'Kinija', 9879879879, 879879879, '879879879', '2021-01-10 16:52:44'),
(71, 'Graikija', 123, 123, 'GRE123', '2021-01-11 10:45:09'),
(82, 'Belgija', 0, 0, '', '2021-01-04 12:31:52'),
(83, 'Brazilija', 0, 0, '', '2021-01-05 12:31:58'),
(84, 'Danija', 0, 0, '', '2021-01-07 12:32:05'),
(85, 'JAV', 0, 0, '', '2021-01-10 12:32:59'),
(86, 'Kipras', 0, 0, '', '2021-01-06 13:34:30'),
(87, 'Suomija', 0, 0, '', '2021-01-04 12:33:18'),
(88, 'Turkija', 0, 0, '', '2021-01-07 12:33:24'),
(89, 'Zambija', 0, 0, '', '2021-01-08 12:33:33'),
(90, 'Vokietija', 0, 0, '', '2021-01-09 12:33:42'),
(93, 'Lenkija', 222, 333, 'PL - 22d', '2021-01-11 14:45:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_country` (`fk_country`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cities`
--
ALTER TABLE `cities`
  ADD CONSTRAINT `cities_ibfk_1` FOREIGN KEY (`fk_country`) REFERENCES `countries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
