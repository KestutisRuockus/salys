<?php

require_once './database.php';

$id = $_GET['id'] ?? null;
$cityName = $_GET['name'];
$country = $_GET['country'] ?? null;
$msg = '';
$table = '';

echo "COUNTRY = " .$country . '<br>';


// Find out from which page came - city or country.
// Selecting which table to update
///////////////////////////////////
if(isset($_POST['edit'])){
    if(empty($country)){
        $table = 'cities';
    }else {
        $table = 'countries';

    }

// Update City or Country by id
////////////////////////////////
if(empty($id)){
    $msg = 'Failed Updating...';
    echo "if emty - ID = " . $id . '<br>';
    } else {
        $name = $_POST['name'];
        $area = $_POST['area'];
        $population = $_POST['population'];
        $code = $_POST['code'];

        $statement = $pdo->prepare('UPDATE ' . $table . ' SET name = :name, area = :area,
                population = :population, code = :code, date = :date WHERE id = :id');

        $statement->bindValue(':name', $name);
        $statement->bindValue(':area', $area);
        $statement->bindValue(':population', $population);
        $statement->bindValue(':code', $code);
        $statement->bindValue(':date', date('Y-m-d H:i:s'));
        $statement->bindValue(':id', $id) . '<br>';

        $statement->execute();
        $msg = 'Record successfully Updated';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css">

    <title>Document</title>
</head>
<body>
<form  class="addRecord" action="" method="POST">
    <h1>Updating <?php echo $cityName ?> </h1>
    <label>Name</label>
    <input type="text" placeholder="Name" name="name">
    <label>Area, km²</label>
    <input type="number" placeholder="Area, km²" name="area">
    <label>Population</label>
    <input type="number" placeholder="Population" name="population">
    <label>Code</label>
    <input type="text" placeholder="" name="code">
    <input type="submit" class="inputSubmit" value="Submit" name="edit"></input>
    <p><?php echo $msg ?></p>
</form>
    
</body>
</html>