<?php
session_start();

include_once './database.php';
$msg = $_GET['msg'] ?? '';
$search = $_GET['search'] ?? '';
$sortFrom = $_GET['sortFrom'] ?? '';
$sortTo = $_GET['sortTo'] ?? date('Y-m-d H');
$a0 = '00:00:00';
$b0 = '23:59:59';

$RecordsPerPage = 10;
$page = '1';

// GET selected page of table
if(isset($_GET['page'])){
    $page = $_GET['page'];
    } else{
        $page = 1;
}

$startFrom = ($page - 1) * $RecordsPerPage;

// ASC / DESC submit input
$sort = $_SESSION['sort'];
if(isset($_GET['sort'])){
    if($sort == 'ASC'){
        $sort = 'DESC';
        $_SESSION['sort'] = $sort;
    } else {
        $sort = 'ASC';
        $_SESSION['sort'] = $sort;
    }
}

// Check input of picked date
if(empty($sortFrom)){
    $sortFrom = '2021-01-01';
    $sqlBetween = '';
} else {
    if(empty($sortTo)){
        $sortTo = date('Y-m-d');
    }
    $sqlBetween = 'WHERE date BETWEEN "' . $sortFrom . ' ' . $a0 . '" AND "' . $sortTo . ' ' . $b0 . '" ';
}

// echo 'SQLBETWEEN = ' . $sqlBetween . '<br>';

// Check or seacrh input was entered
/////////////////////////////////////
if ($search) {
    $statement = $pdo->prepare('SELECT * FROM countries WHERE name LIKE :name AND date BETWEEN "' . $sortFrom . ' ' . $a0 . '" AND "' . $sortTo . ' ' . $b0 . '" ORDER BY name ' . $sort . ' LIMIT ' . $startFrom . ", " . $RecordsPerPage);
    $statement->bindValue(':name', "%$search%");
    echo '<br>';
} else {
    $statement = $pdo->prepare('SELECT * FROM countries ' . $sqlBetween . ' ORDER BY name ' . $sort . ' LIMIT ' . $startFrom . ", " . $RecordsPerPage);
}
$statement->execute();
$countries = $statement->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css">

    <title>Countries</title>
</head>
<body>
<h1>All Countries</h1>
<div style="display: flex; margin-bottom: 15px">
    <form style="margin-right: 5%;" action="" method="GET">
        <input type="submit" name="sort" value="<?php echo $sort ?>">
    </form>
    <form action="" method="$_GET">
        <input type="date" placeholder=" From" name="sortFrom" value="<?php echo $sortFrom ?>">
        <input type="date" placeholder=" To" name="sortTo" value="<?php echo $sortTo ?>">
        <input type="text" placeholder=" Search" name="search" value="<?php echo $search ?>">
        <button type="submit">Search</button>
    </form>
</div>
<div class="allCountries">
    <table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Country Area, km²</th>
            <th>Population</th>
            <th>Country Phone Code</th>
            <th>Record Create Date</th>
            <th>Operations</th>
        </tr>
    </thead>
    <?php foreach($countries as $i => $country): ?>
            <tbody>
                <tr>
                <td><?php echo $i +1 ?></td>
                <td>
                    <form action="cities.php?id=<?php echo $country['id']?>&name=<?php echo $country['name']?>" method="POST">
                        <input class="name" type="submit" name="submitCountry" value="<?php echo $country['name'] ?>">
                    </form>
                </td>
                <td><?php echo $country['area'] ?></td>
                <td><?php echo $country['population'] ?></td>
                <td><?php echo $country['code'] ?></td>
                <td><?php echo $country['date'] ?></td>
                <td>
                    <div style="display: flex;">
                        <a class="edit" href="update.php?id=<?php echo $country['id']?>&name=<?php echo $country['name']?>&country=1">Edit</a>
                        <form action="delete.php" method="POST">
                            <input type="hidden" name="id" value="<?php echo $country['id'] ?>">
                            <input  type="submit" value="Delete"></input>
                        </form>
                    </div>
                </td>
                </tr>
            </tbody>
                <?php endforeach; ?>
    </table>
                <!-- Gets number of rows from database and sets number of table pages-->
                <!-- ----------------------------------------------- -->
    <div>
        <?php
            $statement = $pdo->prepare('SELECT count(*) list FROM countries WHERE name LIKE :name');
            $statement->bindValue(':name', "%$search%");
            $statement->execute();
            $list = $statement->fetch(PDO::FETCH_COLUMN);
            $totalPages = ceil($list/$RecordsPerPage);
            for($i=1; $i<=$totalPages; $i++){
                echo "<a style='margin:3px' href='index.php?page=" . $i . "'>" . $i . "</a>";
            }

        ?>
    </div>
    <p><?php echo $msg; ?></p>
</div>
            <!-- button to show and hide create new country form -->
            <!-- ----------------------------------------------- -->
<button id="btnAddCountry" class="btnAdd" type="button" onclick="showHideAdd()">Add Country</button>


                <!-- Form to create new country -->
                <!-- ----------------------------------------------- -->
<div style="display: flex;">
    <div id="addCountry" class="addRecord" style="visibility: hidden">
        <form  class="addRecord" action="create.php" method="POST">
            <h1>Add Country</h1>
            <label>Country name</label>
            <input type="text" placeholder="Country name" name="name">
            <label>Country area, km²</label>
            <input type="number" placeholder="Country area, km²" name="area">
            <label>Population</label>
            <input type="number" placeholder="Population" name="population">
            <label>Country phone code</label>
            <input type="text" placeholder="Country phone code" name="phoneCode">
            <input type="submit" class="inputSubmit" method="POST" value="Submit" name="submitCountry"></input>
        </form>
    </div>

                <!-- JS script to show div of 'Add Form' -->
                <!-- ----------------------------------------------- -->
<script type="text/javascript">
    var addDiv = document.getElementById('addCountry');
    function showHideAdd(){
        console.log(addDiv.style.visibility);
        if(addDiv.style.visibility == 'hidden'){
            addDiv.style.visibility = 'visible';
        } 
        else if (addDiv.style.visibility == 'visible'){
            addDiv.style.visibility = 'hidden';
        }
}
</script>

</body>
</html>