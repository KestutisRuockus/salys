<?php
session_start();

require_once './database.php';

// Create new Country
//////////////////////
if(isset($_POST['submitCountry'])){
    $name = $_POST['name'];
    $area = $_POST['area'];
    $population = $_POST['population'];
    $phoneCode = $_POST['phoneCode'];

        $statement = $pdo->prepare('INSERT INTO countries (name, area, population, code, date)
            VALUES (:name, :area, :population, :phoneCode, :date)');

        $statement->bindValue(':name', $name);
        $statement->bindValue(':area', $area);
        $statement->bindValue(':population', $population);
        $statement->bindValue(':phoneCode', $phoneCode);
        $statement->bindValue(':date', date('Y-m-d H:i:s'));
        $statement->execute();
        header("Location: index.php?msg=<?php $msg ?>");
        $msg = "Record successfully created";
        
}

// Create new City
//////////////////
if(isset($_POST['submitCity'])){
    $fk = $_SESSION['countryId'];
    $name = $_POST['name'];
    $area = $_POST['area'];
    $population = $_POST['population'];
    $postalCode = $_POST['postalCode'];

        $statement = $pdo->prepare('INSERT INTO cities (fk_country, name, area, population, code, date)
            VALUES (:fk_country, :name, :area, :population, :postalCode, :date)');

        $statement->bindValue(':fk_country', $fk);
        $statement->bindValue(':name', $name);
        $statement->bindValue(':area', $area);
        $statement->bindValue(':population', $population);
        $statement->bindValue(':postalCode', $postalCode);
        $statement->bindValue(':date', date('Y-m-d H:i:s'));
        $statement->execute();
        header("Location: cities.php");
        
}

